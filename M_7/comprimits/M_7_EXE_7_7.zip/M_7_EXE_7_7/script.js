"use strict";

function esBisiesto() {
  let year = parseInt(document.getElementById("year").value);
  let resultDiv = document.getElementById("result");
  resultDiv.innerHTML = verificarYear(year) + "<br>";
  resultDiv.innerHTML += verificarYear(year);
}

function verificarYear(year) {
  let bisiesto = true;
  if (year % 400 === 0) {
    bisiesto = "El año " + year + " es bisiesto";
  } else if (year % 4 == 0 && !(year % 100 == 0)) {
    bisiesto = "El año " + year + " es bisiesto";
  } else {
    bisiesto = "El año " + year + " no es bisiesto";
  }
  return bisiesto;
}

function hacerTernario(year) {
  //por qué me gusta el ternario
  return year % 400 == 0 || !(year % 4 == 0 && year % 100)
    ? "el año es bisiesto"
    : "el año no es bisiesto";

}
