"use strict";





function començar() {
  let numParaules = parseInt(prompt("Quantes paraules vols introduir?"));
  let arrayParaules = [];
  let resultDiv = document.getElementById("result");

  for (let index = 0; index < numParaules; index++) {
    let paraula = prompt("Introdueix les paraules");
    arrayParaules.push(paraula);
  }

  for (let index = 0; index < arrayParaules.length; index++) {
    resultDiv.innerHTML += arrayParaules[index] + " ";
}

}

